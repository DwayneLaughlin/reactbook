module.exports = {
  Post: require("./post")
};
